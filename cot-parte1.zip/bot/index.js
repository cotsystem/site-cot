require("dotenv").config();
const {
  Client,
  GatewayIntentBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  SlashCommandBuilder,
  REST,
  Routes,
  MessageFlags
} = require("discord.js");

const CONFIG = {
  token: process.env.DISCORD_TOKEN,
  guildId: "1565699574499250289",
  recruitmentChannelId: "1566998986588557403",
  panelChannelId: "1565700376106111066",
  // Substitua pela URL final do seu GitHub Pages (ex: https://seuusuario.github.io/cot-portal/)
  portalUrl: "https://SEU-USUARIO.github.io/cot-portal/",
  editalVersion: "Edital COT v1.0",
  allowedCommandRoles: [
    "1565700376106111066",
    "1567160512188387398",
    "1566294929863606272"
  ],
  themeColor: 0x0f172a,
  accentColor: 0x1d4ed8
};

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ]
});

function hasAllowedRole(member) {
  if (!member) return false;
  return CONFIG.allowedCommandRoles.some((roleId) => member.roles.cache.has(roleId));
}

function buildPortalPanelMessage() {
  const embed = new EmbedBuilder()
    .setColor(CONFIG.themeColor)
    .setTitle("🎖️ COMANDO DE OPERAÇÕES TÁTICAS — PORTAL & EDITAL")
    .setDescription(
      `Bem-vindo ao sistema oficial da **COT** (${CONFIG.editalVersion}).\n` +
      "Acesse o portal abaixo para ler o edital completo, revisar os slides e enviar sua ficha."
    )
    .addFields(
      {
        name: "📜 1. Edital & Slides",
        value: "Leia o edital oficial e os slides operacionais diretamente no portal.",
        inline: false
      },
      {
        name: "🪪 2. Identificação",
        value: "Padrão oficial dos aprovados: `「COT」NOME 「ID」`.",
        inline: false
      }
    )
    .setFooter({ text: `COT • ${CONFIG.editalVersion}` })
    .setTimestamp();

  const row = new ActionRowBuilder().addComponents(
    new ButtonBuilder()
      .setLabel("Acessar Portal COT")
      .setEmoji("🌐")
      .setStyle(ButtonStyle.Link)
      .setURL(CONFIG.portalUrl),
    new ButtonBuilder()
      .setCustomId("cot_id_tutorial")
      .setLabel("Como pegar o ID?")
      .setEmoji("❓")
      .setStyle(ButtonStyle.Secondary)
  );

  return { embeds: [embed], components: [row] };
}

function buildIdTutorialEmbed() {
  return new EmbedBuilder()
    .setColor(CONFIG.accentColor)
    .setTitle("🪪 Como pegar o seu ID do Discord?")
    .setDescription("Siga os passos abaixo de acordo com seu dispositivo:")
    .addFields(
      {
        name: "💻 No PC / Navegador",
        value:
          "1. Abra **Configurações de Usuário** (⚙️).\n" +
          "2. Vá em **Avançado** e ative **Modo Desenvolvedor**.\n" +
          "3. Clique com o botão direito no seu perfil e escolha **Copiar ID de usuário**.",
        inline: false
      },
      {
        name: "📱 No Celular",
        value:
          "1. Toque no seu avatar e vá em **Configurações** (⚙️).\n" +
          "2. Entre em **Avançado** e ative **Modo Desenvolvedor**.\n" +
          "3. Abra seu perfil, toque nos **•••** e escolha **Copiar ID de usuário**.",
        inline: false
      }
    )
    .setFooter({ text: "COT • Guia Rápido" });
}

async function registerSlashCommands() {
  if (!CONFIG.token || !client.user) return;

  const commands = [
    new SlashCommandBuilder()
      .setName("painel-rec")
      .setDescription("Publica o painel oficial do portal COT com link para o site")
      .toJSON()
  ];

  const rest = new REST({ version: "10" }).setToken(CONFIG.token);
  await rest.put(Routes.applicationGuildCommands(client.user.id, CONFIG.guildId), {
    body: commands
  });
}

client.once("clientReady", async () => {
  console.log(`✅ [PARTE 1] Bot COT online como ${client.user.tag}`);
  try {
    await registerSlashCommands();
    console.log("✅ Comando /painel-rec registrado.");
  } catch (err) {
    console.error("Erro ao registrar comandos:", err);
  }
});

client.on("interactionCreate", async (interaction) => {
  try {
    if (interaction.isChatInputCommand() && interaction.commandName === "painel-rec") {
      if (!hasAllowedRole(interaction.member)) {
        return interaction.reply({
          content: "❌ Você não tem permissão para usar este comando.",
          flags: MessageFlags.Ephemeral
        });
      }

      await interaction.reply({
        content: "✅ Painel publicado.",
        flags: MessageFlags.Ephemeral
      });
      return interaction.channel.send(buildPortalPanelMessage());
    }

    if (interaction.isButton() && interaction.customId === "cot_id_tutorial") {
      return interaction.reply({
        embeds: [buildIdTutorialEmbed()],
        flags: MessageFlags.Ephemeral
      });
    }
  } catch (err) {
    console.error("Erro em interactionCreate:", err);
  }
});

client.login(CONFIG.token);
